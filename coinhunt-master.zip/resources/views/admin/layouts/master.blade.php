@include('admin.layouts.header')
@include('admin.layouts.menu')
@yield('content')
@include('admin.layouts.footer')
