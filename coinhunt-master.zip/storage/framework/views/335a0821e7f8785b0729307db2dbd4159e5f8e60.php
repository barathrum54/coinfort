<?php $__env->startSection('title',$app->name.' Coinini Güncelle'); ?>
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary"><?php echo $__env->yieldContent('title'); ?></h6>
        </div>
        <div class="card-body">
            <?php if(Session::get("success")): ?>
                <div class="alert alert-success"><?php echo e(Session::get("success")); ?></div>
                <?php endif; ?>
            <form action="<?php echo e(url("/admin/applications/a/$app->id")); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php $__errorArgs = ["name"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="form-group">
                    <label>Coin Adı</label>
                    <input type="text" name="name" class="form-control" value="<?php echo e($app->name); ?>" required>
                </div>
                <?php $__errorArgs = ["symbol"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="form-group">
                    <label>Coin Symbol</label>
                    <input type="text" value="<?php echo e($app->symbol); ?>" name="symbol" class="form-control" required>
                </div>
                <?php $__errorArgs = ["description"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="form-group">
                    <label>Coin Description</label>
                    <textarea type="text" name="description" class="form-control" required><?php echo e($app->description); ?></textarea>
                </div>
                <?php $__errorArgs = ["logo"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="form-group">
                    <label>Coin icon</label>
                    <input type="text" value="<?php echo e($app->logo); ?>" name="icon" class="form-control" required>
                </div>
                <?php $__errorArgs = ["launch_date"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                
                <div class="form-group">
                    <label>Coin Launch Date</label>
                    <input type="date"   value="<?php echo e($app->launch_date); ?>"  name="launch_date" class="form-control" required>
                </div>
                <?php $__errorArgs = ["telegram"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="form-group">
                    <label>Coin Telegram</label>
                    <input type="text" value="<?php echo e($app->telegram); ?>"  name="telegram" class="form-control" required>
                </div>
                <?php $__errorArgs = ["website"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="form-group">
                    <label>Coin Website</label>
                    <input name="website" value="<?php echo e($app->website); ?>"  type="text" class="form-control">
                </div>
                <?php $__errorArgs = ["twitter"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="form-group">
                    <label>Coin Twitter</label>
                    <input name="twitter" value="<?php echo e($app->twitter); ?>"  type="text" class="form-control">
                </div>
                <?php $__errorArgs = ["discord"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="form-group">
                    <label>Coin Discord</label>
                    <input name="discord" value="<?php echo e($app->discord); ?>"  type="text" class="form-control">
                </div>
                <?php $__errorArgs = ["reddit"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="form-group">
                    <label>Coin Reddit</label>
                    <input name="reddit"  value="<?php echo e($app->reddit); ?>"  type="text" class="form-control">
                </div>
                <?php $__errorArgs = ["market_cap"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="form-group">
                    <label>Coin MarketCap</label>
                    <input name="market_cap" value="<?php echo e($app->market_cap); ?>"  type="text" class="form-control">
                </div>
                <?php $__errorArgs = ["price"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="form-group">
                    <label>Coin Price In Usd</label>
                    <input name="price" value="<?php echo e($app->price); ?>"  type="text" class="form-control">
                </div>
                <?php $__errorArgs = ["promoted"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="form-group">
                    <label>Is Coin Promoted </label>
                    <select name="promoted" class="form-control" required>
                        <option value="0">No</option>
                        <option value="1">Yes</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>contact</label>
                    <input name="contact" value="<?php echo e($app->contact); ?>"  type="text" class="form-control">
                </div>
                <div class="form-group">
                    <label>chain</label>
                    <input name="chain" value="<?php echo e($app->chain); ?>"  type="text" class="form-control">
                </div>
                <div class="form-group">
                    <label>info</label>
                    <input name="info" value="<?php echo e($app->info); ?>"  type="text" class="form-control">
                </div>
                <div class="form-group">
                    <label>Contract Adress</label>
                    <input name="contract_adress" value="<?php echo e($app->contract_adress); ?>"  type="text" class="form-control">
                </div>
                
                <div class="form-group">
                    <button class="btn btn-primary btn-block" type="submit">Approve</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\win10\Desktop\coinhunt-master\resources\views/admin/applications/detail.blade.php ENDPATH**/ ?>