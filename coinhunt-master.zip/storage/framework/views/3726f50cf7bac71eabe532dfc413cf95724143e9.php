<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('topads', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section>
        <div class="detail-panel">

            <div class="row">
                <div class="col-12 col-lg-10">
                    <div class="row detail-name-row">
                        <div class="col-12 col-lg-1">
                            <img class="detail-logo" src="<?php echo e($coin->icon); ?>" alt="">
                        </div>
                        <div class="col-12 col-lg-4 d-flex flex-column ">
                            <h2 class="detail-name"><?php echo e($coin->name); ?></h2>
                            <div class="d-flex justify-content-start detail-name-inner-row">
                                <h3 class="detail-ticker"><?php echo e($coin->symbol); ?></h3>
                                <h3 class="detail-votes"><span
                                        style="font-size: 18px"><?php echo e($coin->votes); ?></span>&nbsp;&nbsp; Vote </h3>
                            </div>
                        </div>
                    </div>
                    <?php if($coin->chain != null && $coin->contract_adress != null): ?>
                        
                    <div class="row ">
                        <div class="col-12">
                            <div class="detail-contract">
                                <?php echo e($coin->chain); ?> : <?php echo e($coin->contract_adress); ?>

                            </div>
                        </div>
                    </div>
                    <?php endif; ?>

                    <div class="row">
                        <div class="col-12 d-flex justify-content-between detail-info-row">
                            <div class="detail-info-snip">
                                <span>Market Cap</span> <?php echo e($coin->market_cap); ?>

                            </div>
                            <div class="detail-info-snip">
                                <span>Price</span> <?php echo e($coin->price); ?>

                            </div>
                            <div class="detail-info-snip">
                                <span>Launch Date</span> <?php echo e($coin->launch_date); ?>

                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <div class="detail-description">
                                <?php echo e($coin->description); ?>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-lg-2 d-flex  align-items-center flex-column">
                    <a name="" id="" class="detail-btn" href="<?php echo e($coin->website); ?>" target="_blank" role="button">Visit Web Site</a>
                    <a name="" id="" class="detail-btn" href="<?php echo e($coin->telegram); ?>" target="_blank" role="button">Join Telegram</a>
                    <a name="" id="" class="detail-btn" href="<?php echo e($coin->twitter); ?>" target="_blank" role="button">Follow Twitter</a>
                </div>
            </div>
            <div class="row">
                <div class="col-12 text-center ">
                    <?php if($coin->voted): ?>
                        <div class="col coin-col  voteButton">
                            <button class="upvote-button voted detail" disabled id="<?php echo e($coin->id); ?>">🚀
                                <?php if($coin->votes == null): ?> <span id="voteNumber">0</span>
                                <?php else: ?> <span id="voteNumber">Vote</span>
                                <?php endif; ?>
                            </button>
                        </div>
                    <?php else: ?>
                        <div class="col coin-col  voteButton">
                            <button class="upvote-button detail" id="<?php echo e($coin->id); ?>">🚀
                                <?php if($coin->votes == null): ?> <span id="voteNumber">0</span>
                                <?php else: ?> <span id="voteNumber">Vote</span>
                                <?php endif; ?>
                            </button>
                        </div>
                    <?php endif; ?>
                    <br>
                    <span style="opacity: .8">You can vote once every 12 hours </span>

                </div>
            </div>
        </div>

    </section>
    <?php echo $__env->make('promoted-list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\win10\Desktop\coinhunt-master\resources\views/coindetail.blade.php ENDPATH**/ ?>