
<section class="mt-5 banner-wrap">
    <?php $__currentLoopData = $ads1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row banner-first-row">
            <div class="col text-center">
                <a href="<?php echo e($ad->url); ?>" style="width: fit-content">
                    <img src="<?php echo e($ad->photo); ?>" class="banner-first" alt="">
                </a>
            </div>
        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</section><?php /**PATH C:\Users\win10\Desktop\coinhunt-master\resources\views/topads.blade.php ENDPATH**/ ?>