<section class="section-margin">
    <div class="main-table-wrap">
        <div class="main-table ">
            <div class="row ">
                <div class="col-12 ">
                    <div class="row mx-0 gradient-border">
                        <div class="col list-header" style="border-radius: 15px 0px 0px 0px;padding: 10px;">
                            💎 Promoted Coins</div>
                        <div class="col d-none d-lg-block list-header">Symbol</div>
                        <div class="col list-header">Market Cap</div>
                        <div class="col d-none d-lg-block list-header">Launch</div>
                        <div class="col list-header" style="border-radius: 0px 15px 0px 0px;">Upvotes</div>
                    </div>
                </div>
            </div>

            <?php $__currentLoopData = $promoted_coins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promoted_coin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="/coin/<?php echo e($promoted_coin->id); ?>">

                    <div class="row text-center coin-row promoted-row">
                        <div class="col coin-col ">
                            <div class="row w-100">
                                <div class="col-6 col-lg-4">
                                    <img src="<?php echo e($promoted_coin->icon); ?>" class="coin-logo" alt="">
                                </div>
                                <div class="col-6 col-lg-8 coin-name">
                                    <?php echo e($promoted_coin->name); ?>

                                </div>

                            </div>
                        </div>

                        <div class="col coin-col d-none d-lg-block">
                            <?php echo e($promoted_coin->symbol); ?>

                        </div>

                        <div class="col coin-col ">
                            <?php echo e($promoted_coin->market_cap); ?>

                        </div>
                        <div class="col coin-col d-none d-lg-block ">
                            <?php echo e($promoted_coin->launch_date); ?>

                        </div>
                        <?php if($promoted_coin->voted): ?>
                            <div class="col coin-col  voteButton">
                                <button class="upvote-button voted" disabled id="<?php echo e($promoted_coin->id); ?>">🚀
                                    <?php if($promoted_coin->votes == null): ?> <span
                                            id="voteNumber">0</span>
                                    <?php else: ?> <span id="voteNumber"><?php echo e($promoted_coin->votes); ?></span>
                                    <?php endif; ?>
                                </button>
                            </div>
                        <?php else: ?>
                            <div class="col coin-col  voteButton">
                                <button class="upvote-button" id="<?php echo e($promoted_coin->id); ?>">🚀
                                    <?php if($promoted_coin->votes == null): ?> <span
                                            id="voteNumber">0</span>
                                    <?php else: ?> <span id="voteNumber"><?php echo e($promoted_coin->votes); ?></span>
                                    <?php endif; ?>
                                </button>
                            </div>
                        <?php endif; ?>
                    </div>
                </a>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </div>
    </div>
</section><?php /**PATH C:\Users\win10\Desktop\coinhunt-master\resources\views/promoted-list.blade.php ENDPATH**/ ?>