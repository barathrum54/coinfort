<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary"><strong><?php echo e($categories->count()); ?> Kategori Bulunudu.</strong></h6>
        </div>
        <div class="card-body">
            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-danger"><?php echo e($error); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php if(Session::get("success")): ?>
                <div class="alert alert-success"><?php echo e(Session::get("success")); ?></div>
            <?php endif; ?>
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                    <tr>
                        <th>Kateogri ID</th>
                        <th>Kategori Adı</th>
                        <th>Kategoriye Ait Makale Sayısı</th>
                        <th>Kategori Oluşturulma Tarihi</th>
                        <th>İşlemler</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($category->id); ?></td>
                            <td><?php echo e($category->name); ?></td>
                            <td><?php echo e($category->getArticles()->count()); ?></td>
                            <td><?php echo e($category->created_at->diffForHumans()); ?></td>
                            <td style="display: flex; flex-wrap: nowrap;">
                                <a target="_blank" href="" title="Görüntüle" class="btn btn-sm btn-success mr-2"><i class="fa fa-eye"></i></a>
                                <a href="<?php echo e(url("/admin/categories/$category->id/edit")); ?>" title="Düzenle" class="btn btn-sm btn-primary mr-2"><i class="fa fa-pen"></i></a>
                                <form method="POST" action="<?php echo e(url("/admin/categories/$category->id")); ?>" title="Sil">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field("delete"); ?>
                                    <button class="btn btn-sm btn-danger"><i class="fa fa-times"></i></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\win10\Desktop\coinhunt-master\resources\views/admin/category/index.blade.php ENDPATH**/ ?>